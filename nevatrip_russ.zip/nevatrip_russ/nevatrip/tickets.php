<!DOCTYPE html>
<html lang="en">
<head>
    <title>Tickets</title>
    <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>

<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

// подключение к базе данных
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'nevatrip_db';

$mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);

// проверка ошибок
if ($mysqli->connect_error) {
    printf("Connection error: %s\n", $mysqli->connect_error);
    exit();
}


//функция генерирования рандомных чисел
function generateRandom($length = 8) {
    $barcode = '';
    for ($i = 0; $i < $length; $i++) {
        $barcode .= random_int(0, 9);
    }
    return $barcode;
}


// мок к API
function mockApiResponse($event_id, $event_date, $ticket_adult_price, $ticket_adult_quantity, $ticket_kid_price, $ticket_kid_quantity, $ticket_group_price, $ticket_group_quantity, $ticket_discounted_price, $ticket_discounted_quantity, $barcode) {
    $responses = [
        ['message' => 'order successfully booked'],
        ['error' => 'barcode already exists'],
        ['error' => 'event cancelled'],
        ['error' => 'no tickets'],
        ['error' => 'no seats'],
        ['error' => 'fan removed'],
    ];
    return $responses[array_rand($responses)];
}

// функция букинга билетов
function bookOrder($event_id, $event_date, $ticket_adult_price, $ticket_adult_quantity, $ticket_kid_price, $ticket_kid_quantity, $ticket_group_price, $ticket_group_quantity, $ticket_discounted_price, $ticket_discounted_quantity, $barcode) {
    while (true) {
        $result = mockApiResponse($event_id, $event_date, $ticket_adult_price, $ticket_adult_quantity, $ticket_kid_price, $ticket_kid_quantity, $ticket_group_price, $ticket_group_quantity, $ticket_discounted_price, $ticket_discounted_quantity, $barcode);
        if (isset($result['message']) && $result['message'] === 'order successfully booked') {
            return true;
        } elseif (isset($result['error'])) {
            if (in_array($result['error'], ['barcode already exists', 'event cancelled', 'no tickets', 'no seats', 'fan removed'])) {
                $barcode = generateRandom(4);
            } else {
                echo "<p>Error processing booking: " . $result['error'] . "</p>";
                return false;
            }
        }
    }
}

// функция генерации баркода для каждого билета
function generateRandomEachTicket($event_id, $length = 4) {
    $unique_id = random_int(0, 9999);
    return $event_id . '-'.str_pad($unique_id, $length, '0', STR_PAD_LEFT);
}

// функция для вставки в таблицу each ticket - phpmyadmin
function insertEachTicket($mysqli, $event_id, $event_date, $ticket_price, $quantity, $user_id) {
    for ($i = 0; $i < $quantity; $i++) {
        $barcode_each_ticket = generateRandomEachTicket($event_id);
        $query = "INSERT INTO each_ticket (event_id, event_date, ticket_price, barcode_each_ticket, user_id, created) VALUES (?, ?, ?, ?, ?, NOW())";
        if ($stmt = $mysqli->prepare($query)) {
            $stmt->bind_param("isdsi", $event_id, $event_date, $ticket_price, $barcode_each_ticket, $user_id);
            if (!$stmt->execute()) {
                echo "<p>Error inserting each ticket: " . $stmt->error . "</p>";
            }
            $stmt->close();
        } else {
            echo "<p>Error preparing each ticket statement: " . $mysqli->error . "</p>";
        }
    }
}


// Main booking logic
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_id = generateRandom(4);
    $event_date = $_POST['event-date'];
    $ticket_adult_quantity = $_POST['ticket-adult-quantity'];
    $ticket_kid_quantity = $_POST['ticket-kid-quantity'];
    $ticket_group_quantity = $_POST['ticket-group-quantity'];
    $ticket_discounted_quantity = $_POST['ticket-discounted-quantity'];

    $ticket_adult_price = 700; 
    $ticket_kid_price = 450;   
    $ticket_group_price = 300; 
    $ticket_discounted_price = 200;  

    $barcode = generateRandom(4);   
    $user_id = $_COOKIE['user_id'];                
    $equal_price = ($ticket_adult_quantity * $ticket_adult_price) + 
                   ($ticket_kid_quantity * $ticket_kid_price) + 
                   ($ticket_group_quantity * $ticket_group_price) + 
                   ($ticket_discounted_quantity * $ticket_discounted_price);

    if (bookOrder($event_id, $event_date, $ticket_adult_price, $ticket_adult_quantity, $ticket_kid_price, $ticket_kid_quantity, $ticket_group_price, $ticket_group_quantity, $ticket_discounted_price, $ticket_discounted_quantity, $barcode)) {
        $query = "INSERT INTO trips (event_id, event_date, ticket_adult_price, ticket_adult_quantity, ticket_kid_price, ticket_kid_quantity, ticket_group_price, ticket_group_quantity, ticket_discounted_price, ticket_discounted_quantity, barcode, user_id, equal_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        if ($stmt = $mysqli->prepare($query)) {
            $stmt->bind_param("isiiiissssiii", $event_id, $event_date, $ticket_adult_quantity, $ticket_kid_quantity, $ticket_group_quantity, $ticket_discounted_quantity, $ticket_adult_price, $ticket_kid_price, $ticket_group_price, $ticket_discounted_price, $barcode, $user_id, $equal_price);
            
            if ($stmt->execute()) {
                echo "<p>Tickets booked successfully!</p>";
                
               
                insertEachTicket($mysqli, $event_id, $event_date, $ticket_adult_price, $ticket_adult_quantity, $user_id);
                insertEachTicket($mysqli, $event_id, $event_date, $ticket_kid_price, $ticket_kid_quantity, $user_id);
                insertEachTicket($mysqli, $event_id, $event_date, $ticket_group_price, $ticket_group_quantity, $user_id);
                insertEachTicket($mysqli, $event_id, $event_date, $ticket_discounted_price, $ticket_discounted_quantity, $user_id);

            } else {
                echo "<p>Error booking tickets: " . $stmt->error . "</p>";
            }
            $stmt->close();
        } else {
            echo "<p>Error preparing the statement: " . $mysqli->error . "</p>";
        }
    }
}
?>

<!-- HTML  -->
<p>
    <?php
    if (isset($_COOKIE['user'])) {
        $user = $_COOKIE['user'];
        echo 'Hello, user_id: '.$_COOKIE['user_id'] .'&nbsp login: '. $_COOKIE['user'];
    } else {
        echo "Hello, Guest! Please log in.";
    }
    ?>
</p>

<div class="login-container">
    <h1 class="reg">Neva trip</h1>
    <p>Забронировать ивент.</p>
    <form class="tickets-form" action="" method="post">
        <div class="event-date-group">
            <label for="event-date">Выбери дату:</label>
            <input class="date" type="date" name="event-date" id="event-date" required>
        </div>
        <div class="tickets-group">
            <label for="ticket-adult-quantity">Взрослые билеты - по 700р каждый:</label>
            <select class="tickets" name="ticket-adult-quantity" id="ticket-adult-quantity" required>
                <option value="" disabled selected>Выбери количество</option>
                <?php for ($i = 0; $i <= 10; $i++): ?>
                <option value="<?= $i; ?>"><?= $i; ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="tickets-group">
            <label for="ticket-kid-quantity">Детские билеты - по 450р каждый:</label>
            <select class="tickets" name="ticket-kid-quantity" id="ticket-kid-quantity" required>
                <option value="" disabled selected>Выбери количество</option>
                <?php for ($i = 0; $i <= 10; $i++): ?>
                <option value="<?= $i; ?>"><?= $i; ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="tickets-group">
            <label for="ticket-group-quantity">Групповые билеты - по 300р каждый:</label>
            <select class="tickets" name="ticket-group-quantity" id="ticket-group-quantity" required>
                <option value="" disabled selected>Выбери количество</option>
                <?php for ($i = 0; $i <= 10; $i++): ?>
                <option value="<?= $i; ?>"><?= $i; ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="tickets-group">
            <label for="ticket-discounted-quantity">Дисконтные билеты - по 200р каждый:</label>
            <select class="tickets" name="ticket-discounted-quantity" id="ticket-discounted-quantity" required>
                <option value="" disabled selected>Выбери количество</option>
                <?php for ($i = 0; $i <= 10; $i++): ?>
                <option value="<?= $i; ?>"><?= $i; ?></option>
                <?php endfor; ?>
            </select>
        </div>


        <input class="tickets" type="submit" name="submit" value="Submit">
    </form>
    <div class="welcome-group">
        <p>Чтобы выйти из системы нажми <a href="/nevatrip/exit.php"><u>сюда</u></a>.</p><br>
    </div>
</div>

<?php
$mysqli->close();
?>

</body>
</html>
