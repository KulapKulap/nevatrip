<?php 

include 'database.php';
?>

<?php
    $login=filter_var(trim($_POST['login']),
    FILTER_SANITIZE_STRING);
    $pass=filter_var(trim($_POST['pass']),
    FILTER_SANITIZE_STRING);


    //размер логина
    if(mb_strlen($login)<5 || mb_strlen($login)>90){
        echo "неподходящая длина логина";
        exit();
    }
    

    //хэш и соль
    $pass=md5($pass."74567458htghrjgr");

    $mysql=new mysqli('localhost', 'root', '', 'nevatrip_db');
    $stmt = $mysql->prepare("INSERT INTO `users` (`login`, `pass`) VALUES('$login', '$pass')");
    $stmt->bind_param("ss", $login, $pass);
    $stmt->execute();



    //переадресация на index.php
    header('Location: /nevatrip/');





?>