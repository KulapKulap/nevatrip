<?php
include "database.php";


$login = htmlspecialchars(trim($_POST['login'])); 
$password = $_POST['password'];



$mysql = new mysqli('localhost', 'root', '', 'nevatrip_db');


if ($mysql->connect_error) {
    die("Connection failed: " . $mysql->connect_error);
}


$query = "INSERT INTO `users` (`login`, `password`) VALUES ('$login', '$password')";


if ($mysql->query($query) === TRUE) {
   
    header('Location: /nevatrip/');
    exit();
} else {
  
    echo "Error: " . $mysql->error;
}

// Close the database connection
$mysql->close();
?>
