<?php


    $login = filter_var(trim($_POST['login']), FILTER_SANITIZE_STRING);
    $password = filter_var(trim($_POST['password']), FILTER_SANITIZE_STRING);

    // защита от SQL injection
    $mysql = new mysqli('localhost', 'root', '', 'nevatrip_db');
    $stmt = $mysql->prepare("SELECT * FROM `users` WHERE `login`=? AND `password`=?");
    $stmt->bind_param("ss", $login, $password);
    $stmt->execute();
    $result = $stmt->get_result();

   
    $user = $result->fetch_assoc();
    
    
    if (!$user) {
        echo "User not found. <a href='index.php'>Go to registration page</a>";

        exit();
    }

  
    setcookie('user', $user['login'], time() + 3600, "/");
    setcookie('user_id', $user['user_id'], time() + 3600, "/");
    setcookie('password', $user['password'], time() + 3600, "/");
    

    $mysql->close();


    header('Location: /nevatrip/');
?>
