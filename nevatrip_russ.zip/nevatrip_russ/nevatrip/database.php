<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);


$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'nevatrip_db';


$mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);


if ($mysqli->connect_error) {
    printf("Connection error: %s\n", $mysqli->connect_error);
    exit();
} else {
}
$mysqli->close();
?>
