<!-- странца для авторизации юзера -->
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css" type="text/css">

</head>
<body>


    <?php
        
        if($_COOKIE['user']==''):
    ?>
    

    <div class="login-container">
    <h1 class="reg">Neva trip</h1>
    <form class="login-form" action="auth.php" method="post">
        <div class="input-group">
        <input class="login" type="text" name="login" placeholder="Логин" required>
        </div>
        <div class="input-group">
        <input class="login" type="password" name="password" placeholder="Пароль" required>
        </div>
        <a class="sign-up-link" href="signup.php">Нет аккаунта? Зарегистрируйся</a>
        <input class="login" type="submit" name="submit" value="Submit">
    </form>




        <?php else: ?>
            
            

            
            


            <form class="welcome-form">
        <div class="welcome-group">
        <b><p class="welcome-message">Привет, user_id: , <i><?php echo $_COOKIE['user_id'] .'&nbsp login: '. $_COOKIE['user']?></i></p></b><br>
        </div>

        
        <div class="welcome-group">
        <p>Чтобы выйти, жми <a href="/nevatrip/exit.php"><u>сюда</u></a>.</p><br>
        </div>
        <div class="welcome-group">
        <p> <a href="/nevatrip/tickets.php"><u>Я хочу забронировать ивент.</u></a>.</p><br>
        </div>
        
    </form>
            
        <?php endif; ?>
    </div>

    <footer>
        <div>
            <p>©2024. All rights reserved.</p>

        </div>
    </footer>

</body>
</html>
