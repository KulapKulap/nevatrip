<!-- странца для регистрации юзера -->
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" type="text/css">
    
</head>
<body>

    <div class="login-container">

        <h1 class="reg">Neva trip</h1>
        <form class="signup-form" action="reg.php" method="post" onsubmit="return validatePassword()">
            <input class="login" type="text" name="login" placeholder="Логин" required><br>
            <input class="login" type="password" name="password" id="password_1" placeholder="Пароль" required><br>
            <input class="login" type="password" name="password" id="password_2"  placeholder="Повтори пароль" required><br>
            <p id="validMessage"></p>
            
            <a class="sign-up-link" href="index.php">Уже есть аккаунт? Войди</a>
            <input class="login" type="submit" name="submit" value="Submit"><br>
        </form>
    </div>

    <script>
        var p1 = document.getElementById("password_1");
        var p2 = document.getElementById("password_2");
        var validMessage = document.getElementById("validMessage");

        function validatePassword() {
            if (p1.value !== p2.value) {
                validMessage.textContent = "Пароли не совпадают!";
                validMessage.style.color = "red";
                return false; 
            } else {
                validMessage.textContent = "";
                return true; 
            }
        }
    </script>

</body>
</html>
